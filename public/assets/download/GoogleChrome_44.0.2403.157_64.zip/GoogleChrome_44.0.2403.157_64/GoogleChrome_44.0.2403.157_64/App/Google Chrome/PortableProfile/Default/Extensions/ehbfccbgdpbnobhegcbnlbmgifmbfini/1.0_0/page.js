// Copyright (c) 2013 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

  
var extension_port = null;
var port = null;

//listen to extension 
function listenExtension(){
  chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
    console.log(sender.tab ?
                "from a content script:" + sender.tab.url :
                "from the extension");
	console.log("extension to content scripts: " + JSON.stringify(request));
	window.postMessage({type:"FROM_CONTENT", data: request}, "*");
  });
}

function listenWebPage(){
	window.addEventListener("message", function(event) {
	  // We only accept messages from ourselves
	  if (event.source != window)
		return;
	  
	  if ( event.data.type && (event.data.type == "FROM_WEB") &&  event.data.data && event.data.data.Func && event.data.data.Paramter) {
		console.log("Web page to Content script: " + JSON.stringify(event.data.data));
		
		//send message to extension
		chrome.runtime.sendMessage(event.data.data, function(response) {
        console.log(response.data.data);
        });
	  }
	}, false);
}

function Init(){
	listenWebPage();
	listenExtension();
}

Init();